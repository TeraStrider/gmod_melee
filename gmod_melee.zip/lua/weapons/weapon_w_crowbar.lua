AddCSLuaFile()
SWEP.Base = "weapon_club"
SWEP.PrintName = "Crowbar"
SWEP.WorldModel = "models/weapons/w_crowbar.mdl"
SWEP.HitDistance = 65
SWEP.Damage = 35
SWEP.Spawnable = true
SWEP.ForceMultiplier = 15
-- SWEP.HoldType = "melee"
SWEP.HitSound	= "Weapon_Crowbar.Melee_Hit"
SWEP.MissSound	= "WeaponFrag.Throw"