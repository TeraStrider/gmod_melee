AddCSLuaFile()
MaterialData = {} 
MaterialData[MAT_FLESH] = {}
MaterialData[MAt_FLESH].Decal = "Impact.Flesh"
MaterialData[MAt_FLESH].Effect = "Blood" 
