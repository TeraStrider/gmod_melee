ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.Spawnable = false
ENT.AdminSpawnable = false 
ENT.CanDamage = true
ENT.CanPickup = false