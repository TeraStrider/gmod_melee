AddCSLuaFile()
ENT.Type = "anim"